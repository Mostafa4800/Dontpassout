import styled from "styled-components";

export const ButtonPos = styled.div`
text-align: center;
display: flex;
justify-content: center;
align-items: center;
text-decoration: none;
padding-top: 50px;
height: 100%;
width: 100%;
border: none;
outline: none;
`