import styled from "styled-components";

export const ButtonPos = styled.div`
    position:absolute;
    top:200px;
    left:720px;
`