import styled from "styled-components";

export const Dash = styled.div`
    display:grid;
    grid-template-columns:0.1fr 0.1fr 0.1fr 0.1fr 0.1fr;
    grid-gap:16px;
    position:absolute;
    left:8.5%;
    top:200px;
`

export const ButtonPos = styled.div`
    position:absolute;
    bottom:150px;
    left:735px;
`