import styled from "styled-components";

export const Container = styled.div`
    position: absolute;
    left:30%;
    text-align:center;
`

export const LogoImage = styled.img`
    width:600px;
    height:auto;
`

export const ExtraText = styled.p`
    color:#bbb9e5;
    font-family: 'Ubuntu', sans-serif;
    position:relative;
    top:-15px;
`